const form = document.querySelector("#comic-form");
const button = document.querySelector("#generate-btn");
const emptyState = document.querySelector("#empty-state");
const output = document.querySelector("#comic-output");

function escapeHTML(value) {
  return String(value ?? "").replace(/[&<>"']/g, char => ({
    "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;"
  })[char]);
}

function renderComic(comic) {
  const panels = (comic.panels || []).map(panel => `
    <article class="panel">
      <h3>Panel ${escapeHTML(panel.panel)} · ${escapeHTML(panel.scene_title)}</h3>
      <p><strong>Scene:</strong> ${escapeHTML(panel.visual)}</p>
      <p><strong>Dialogue:</strong> ${escapeHTML(panel.dialogue)}</p>
      <p><strong>Image prompt:</strong> ${escapeHTML(panel.image_prompt)}</p>
    </article>`).join("");
  output.innerHTML = `
    <div class="comic-heading">
      <div><h2>${escapeHTML(comic.title || "Your Comic")}</h2><div class="pill">${escapeHTML(comic.genre || "Comic")}</div></div>
      <div class="pill">${escapeHTML(comic.mode || "Ready")}</div>
    </div>
    <p class="logline">${escapeHTML(comic.logline || "")}</p>
    ${panels}
    <button class="copy-btn" id="copy-btn" type="button">Copy comic script</button>`;
  output.hidden = false;
  emptyState.hidden = true;
  document.querySelector("#copy-btn").addEventListener("click", async () => {
    const text = `${comic.title}\n${comic.logline}\n\n` + (comic.panels || []).map(p =>
      `Panel ${p.panel}: ${p.scene_title}\nScene: ${p.visual}\nDialogue: ${p.dialogue}\nImage prompt: ${p.image_prompt}`
    ).join("\n\n");
    const copyButton = document.querySelector("#copy-btn");
    try {
      await navigator.clipboard.writeText(text);
      copyButton.textContent = "Copied!";
    } catch {
      copyButton.textContent = "Copy not available in this browser";
    }
  });
}

form.addEventListener("submit", async event => {
  event.preventDefault();
  button.disabled = true;
  button.textContent = "Creating your comic...";
  output.hidden = true;
  emptyState.hidden = false;
  emptyState.innerHTML = "<h2>Creating your story…</h2><p>Preparing your panels.</p>";
  try {
    const response = await fetch("/api/generate", {
      method: "POST",
      headers: {"Content-Type": "application/json"},
      body: JSON.stringify({
        idea: document.querySelector("#idea").value.trim(),
        genre: document.querySelector("#genre").value,
        panel_count: Number(document.querySelector("#panel-count").value)
      })
    });
    const data = await response.json();
    if (!response.ok) throw new Error(data.error || "Something went wrong.");
    renderComic(data);
  } catch (error) {
    emptyState.innerHTML = `<div class="error">${escapeHTML(error.message)}</div><p>Please try again.</p>`;
  } finally {
    button.disabled = false;
    button.textContent = "✦ Create my comic";
  }
});
