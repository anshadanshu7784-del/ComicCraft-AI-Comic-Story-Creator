import os
import json
from flask import Flask, render_template, request, jsonify

app = Flask(__name__)

def demo_comic(idea, genre, count):
    beats = [
        ("The Setup", f"Introduce the main character and the world of: {idea}."),
        ("The Spark", "An unexpected event interrupts an ordinary moment."),
        ("The Discovery", "The hero notices a clue or opportunity."),
        ("The Challenge", "A problem forces the hero to make a choice."),
        ("The Turning Point", "A surprising detail changes the plan."),
        ("The Climax", "The hero takes action and faces the main challenge."),
        ("The Resolution", "The immediate problem begins to settle."),
        ("The Final Beat", "End with a memorable image or a hint of what comes next."),
    ]
    panels = []
    for i in range(count):
        title, scene = beats[i % len(beats)]
        panels.append({
            "panel": i + 1,
            "scene_title": title,
            "visual": f"{scene} Genre: {genre}. Story idea: {idea}",
            "dialogue": "Hero: “We have to find out what happens next!”",
            "image_prompt": f"Illustrate panel {i+1} of a {genre.lower()} comic. {scene} Expressive characters, clear composition, no text in the image."
        })
    return {
        "title": f"The {genre} Story",
        "genre": genre,
        "logline": f"A {genre.lower()} comic inspired by: {idea}",
        "panels": panels
    }

def generate_with_gemini(idea, genre, count):
    from google import genai
    client = genai.Client(api_key=os.environ["GEMINI_API_KEY"])
    prompt = f"""
Create an original comic script as valid JSON only.
Idea: {idea}
Genre: {genre}
Return exactly {count} panels using this schema:
{{"title":"short title","genre":"{genre}","logline":"one sentence",
"panels":[{{"panel":1,"scene_title":"heading","visual":"scene description",
"dialogue":"short dialogue","image_prompt":"visual prompt without lettering"}}]}}
Keep characters and events consistent. Return no Markdown fences.
"""
    response = client.models.generate_content(
        model=os.getenv("GEMINI_MODEL", "gemini-2.5-flash"),
        contents=prompt
    )
    raw = response.text.strip()
    if raw.startswith("```"):
        raw = raw.split("\n", 1)[1].rsplit("```", 1)[0].strip()
    data = json.loads(raw)
    if not isinstance(data.get("panels"), list):
        raise ValueError("Unexpected response format")
    return data

@app.get("/")
def index():
    return render_template("index.html")

@app.post("/api/generate")
def generate():
    payload = request.get_json(silent=True) or {}
    idea = str(payload.get("idea", "")).strip()
    genre = str(payload.get("genre", "Adventure")).strip()
    try:
        count = max(2, min(int(payload.get("panel_count", 4)), 8))
    except (ValueError, TypeError):
        count = 4
    if not idea:
        return jsonify({"error": "Please enter a story idea."}), 400
    if len(idea) > 1200:
        return jsonify({"error": "Keep the idea under 1,200 characters."}), 400

    if os.getenv("GEMINI_API_KEY"):
        try:
            result = generate_with_gemini(idea, genre, count)
            result["mode"] = "Gemini AI"
            return jsonify(result)
        except Exception as exc:
            app.logger.warning("Gemini unavailable; using demo mode: %s", exc)

    result = demo_comic(idea, genre, count)
    result["mode"] = "Demo mode"
    return jsonify(result)

if __name__ == "__main__":
    app.run(debug=True)
