# AI ComicCraft — AI Comic Story Creator

AI ComicCraft turns a short idea into a panel-by-panel comic script with scene descriptions, dialogue, and image prompts. It can use Google's Gemini API when configured and includes demo mode without an API key.

## Features
- Generate a comic title and story outline
- Panel-by-panel scene descriptions and dialogue
- Choose a genre and panel count
- Copy the finished script
- Demo mode works without an API key

**Note:** This starter creates image prompts, not finished AI illustrations. You can connect an image-generation API later.

## Run locally
1. Install Python 3.10+.
2. In this folder, run `pip install -r requirements.txt`.
3. Optional: set your `GEMINI_API_KEY` environment variable.
   - Windows PowerShell: `$env:GEMINI_API_KEY="your_api_key"`
   - macOS/Linux: `export GEMINI_API_KEY="your_api_key"`
4. Run `python app.py`.
5. Open http://127.0.0.1:5000

Never upload your API key to GitHub.

## Tech stack
Python, Flask, Google Gemini API (optional), HTML, CSS, JavaScript.
